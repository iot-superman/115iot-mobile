package com.example.orderapp

object CartManager {
    val items = mutableListOf<CartItem>()

    fun add(food: Food) {
        val existing = items.find { it.food.id == food.id }
        if (existing != null) {
            existing.quantity++
        } else {
            items.add(CartItem(food, 1))
        }
    }

    fun increase(position: Int) {
        if (position in items.indices) items[position].quantity++
    }

    fun decrease(position: Int) {
        if (position !in items.indices) return
        val item = items[position]
        item.quantity--
        if (item.quantity <= 0) items.removeAt(position)
    }

    fun totalCount(): Int = items.sumOf { it.quantity }

    fun totalPrice(): Int = items.sumOf { it.food.price * it.quantity }

    fun clear() = items.clear()
}
