package com.example.orderapp

data class CartItem(
    val food: Food,
    var quantity: Int
)
