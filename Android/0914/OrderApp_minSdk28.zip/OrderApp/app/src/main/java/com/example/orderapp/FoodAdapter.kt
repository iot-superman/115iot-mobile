package com.example.orderapp

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.orderapp.databinding.ItemFoodBinding

class FoodAdapter(
    private var items: List<Food>,
    private val onAdd: (Food) -> Unit
) : RecyclerView.Adapter<FoodAdapter.FoodViewHolder>() {

    inner class FoodViewHolder(val binding: ItemFoodBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FoodViewHolder {
        val binding = ItemFoodBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return FoodViewHolder(binding)
    }

    override fun onBindViewHolder(holder: FoodViewHolder, position: Int) {
        val food = items[position]
        with(holder.binding) {
            foodEmoji.text = food.emoji
            foodName.text = food.name
            foodCategory.text = food.category
            foodPrice.text = "NT$${food.price}"
            addButton.setOnClickListener { onAdd(food) }
        }
    }

    override fun getItemCount(): Int = items.size

    fun updateData(newItems: List<Food>) {
        items = newItems
        notifyDataSetChanged()
    }
}
