package com.example.orderapp

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.orderapp.databinding.ActivityCartBinding

class CartActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCartBinding
    private lateinit var adapter: CartAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCartBinding.inflate(layoutInflater)
        setContentView(binding.root)

        adapter = CartAdapter { updateSummary() }
        binding.cartRecyclerView.layoutManager = LinearLayoutManager(this)
        binding.cartRecyclerView.adapter = adapter

        binding.checkoutButton.setOnClickListener {
            if (CartManager.items.isEmpty()) {
                Toast.makeText(this, "請先加入餐點", Toast.LENGTH_SHORT).show()
            } else {
                startActivity(Intent(this, OrderActivity::class.java))
            }
        }

        updateSummary()
    }

    override fun onResume() {
        super.onResume()
        adapter.notifyDataSetChanged()
        updateSummary()
    }

    private fun updateSummary() {
        binding.totalText.text = "總金額：NT$${CartManager.totalPrice()}"
        binding.emptyText.visibility = if (CartManager.items.isEmpty()) View.VISIBLE else View.GONE
        binding.checkoutButton.isEnabled = CartManager.items.isNotEmpty()
    }
}
