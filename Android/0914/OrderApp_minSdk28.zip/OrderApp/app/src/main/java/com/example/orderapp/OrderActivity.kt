package com.example.orderapp

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.orderapp.databinding.ActivityOrderBinding
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class OrderActivity : AppCompatActivity() {

    private lateinit var binding: ActivityOrderBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityOrderBinding.inflate(layoutInflater)
        setContentView(binding.root)

        refreshSummary()

        binding.diningGroup.setOnCheckedChangeListener { _, checkedId ->
            binding.tableNumberEdit.visibility = if (checkedId == binding.dineInRadio.id) View.VISIBLE else View.GONE
        }

        binding.confirmOrderButton.setOnClickListener {
            if (CartManager.items.isEmpty()) {
                Toast.makeText(this, "購物車是空的", Toast.LENGTH_SHORT).show()
                finish()
                return@setOnClickListener
            }

            val dineIn = binding.dineInRadio.isChecked
            if (dineIn && binding.tableNumberEdit.text.toString().trim().isEmpty()) {
                binding.tableNumberEdit.error = "內用請輸入桌號"
                return@setOnClickListener
            }

            val orderNo = SimpleDateFormat("yyyyMMddHHmmss", Locale.getDefault()).format(Date())
            val mode = if (dineIn) "內用，桌號 ${binding.tableNumberEdit.text}" else "外帶"
            val total = CartManager.totalPrice()
            val note = binding.noteEdit.text.toString().trim().ifEmpty { "無" }

            Toast.makeText(
                this,
                "訂單成立！\n訂單編號：$orderNo\n$mode\n備註：$note\n總金額：NT$$total",
                Toast.LENGTH_LONG
            ).show()

            CartManager.clear()
            finishAffinity()
        }
    }

    private fun refreshSummary() {
        binding.orderSummaryText.text = CartManager.items.joinToString("\n") {
            "${it.food.emoji} ${it.food.name} × ${it.quantity}   NT$${it.food.price * it.quantity}"
        }
        binding.orderTotalText.text = "總金額：NT$${CartManager.totalPrice()}"
    }
}
