package com.example.orderapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.orderapp.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var adapter: FoodAdapter

    private val foodList = listOf(
        Food(1, "牛肉漢堡", 120, "🍔", "主餐"),
        Food(2, "炸雞套餐", 150, "🍗", "主餐"),
        Food(3, "義大利麵", 180, "🍝", "主餐"),
        Food(4, "薯條", 60, "🍟", "點心"),
        Food(5, "雞塊", 70, "🥟", "點心"),
        Food(6, "紅茶", 35, "🧋", "飲料"),
        Food(7, "可樂", 40, "🥤", "飲料"),
        Food(8, "咖啡", 65, "☕", "飲料"),
        Food(9, "冰淇淋", 55, "🍨", "甜點"),
        Food(10, "蛋糕", 80, "🍰", "甜點")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        adapter = FoodAdapter(foodList) { food ->
            CartManager.add(food)
            updateCartButton()
            Toast.makeText(this, "已加入 ${food.name}", Toast.LENGTH_SHORT).show()
        }

        binding.foodRecyclerView.layoutManager = LinearLayoutManager(this)
        binding.foodRecyclerView.adapter = adapter

        setupCategories()

        binding.cartButton.setOnClickListener {
            startActivity(Intent(this, CartActivity::class.java))
        }
    }

    override fun onResume() {
        super.onResume()
        updateCartButton()
    }

    private fun setupCategories() {
        val categories = listOf("全部", "主餐", "點心", "飲料", "甜點")
        categories.forEach { category ->
            val button = Button(this).apply {
                text = category
                setOnClickListener {
                    val data = if (category == "全部") foodList else foodList.filter { it.category == category }
                    adapter.updateData(data)
                }
            }
            binding.categoryContainer.addView(button)
        }
    }

    private fun updateCartButton() {
        binding.cartButton.text = "購物車 ${CartManager.totalCount()} 件  NT$${CartManager.totalPrice()}"
    }
}
