package com.example.orderapp

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.orderapp.databinding.ItemCartBinding

class CartAdapter(
    private val onChanged: () -> Unit
) : RecyclerView.Adapter<CartAdapter.CartViewHolder>() {

    inner class CartViewHolder(val binding: ItemCartBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CartViewHolder {
        val binding = ItemCartBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return CartViewHolder(binding)
    }

    override fun onBindViewHolder(holder: CartViewHolder, position: Int) {
        val item = CartManager.items[position]
        with(holder.binding) {
            cartEmoji.text = item.food.emoji
            cartName.text = item.food.name
            quantityText.text = item.quantity.toString()
            cartSubtotal.text = "NT$${item.food.price * item.quantity}"

            plusButton.setOnClickListener {
                CartManager.increase(holder.bindingAdapterPosition)
                notifyDataSetChanged()
                onChanged()
            }

            minusButton.setOnClickListener {
                CartManager.decrease(holder.bindingAdapterPosition)
                notifyDataSetChanged()
                onChanged()
            }
        }
    }

    override fun getItemCount(): Int = CartManager.items.size
}
