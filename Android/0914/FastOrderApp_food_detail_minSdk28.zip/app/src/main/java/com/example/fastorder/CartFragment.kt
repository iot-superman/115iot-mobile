package com.example.fastorder

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.RadioButton
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class CartFragment : Fragment() {
    private lateinit var adapter: CartAdapter
    private lateinit var tvTotal: TextView
    private lateinit var tvEmpty: TextView
    private lateinit var btnCheckout: Button
    private lateinit var radioDineIn: RadioButton
    private lateinit var etNote: EditText

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        return inflater.inflate(R.layout.fragment_cart, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val recyclerCart = view.findViewById<RecyclerView>(R.id.recyclerCart)
        tvTotal = view.findViewById(R.id.tvTotal)
        tvEmpty = view.findViewById(R.id.tvEmpty)
        btnCheckout = view.findViewById(R.id.btnCheckout)
        radioDineIn = view.findViewById(R.id.radioDineIn)
        etNote = view.findViewById(R.id.etNote)

        adapter = CartAdapter { refresh() }
        recyclerCart.layoutManager = LinearLayoutManager(requireContext())
        recyclerCart.adapter = adapter
        refresh()

        btnCheckout.setOnClickListener {
            if (AppData.cart.isEmpty()) {
                Toast.makeText(requireContext(), "購物車是空的", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val type = if (radioDineIn.isChecked) "內用" else "外帶"
            val no = "A%03d".format(AppData.orders.size + 1)
            AppData.orders.add(Order(no, type, AppData.cart.map { CartItem(it.food, it.quantity) }, AppData.total(), etNote.text.toString()))
            AppData.cart.clear()
            adapter.notifyDataSetChanged()
            refresh()
            Toast.makeText(requireContext(), "訂單完成，取餐號碼 $no", Toast.LENGTH_LONG).show()
        }
    }

    private fun refresh() {
        tvTotal.text = "總金額 NT$ ${AppData.total()}"
        tvEmpty.visibility = if (AppData.cart.isEmpty()) View.VISIBLE else View.GONE
        btnCheckout.isEnabled = AppData.cart.isNotEmpty()
    }
}
