package com.example.fastorder

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.floatingactionbutton.FloatingActionButton

class MainActivity : AppCompatActivity() {
    private lateinit var bottomNavigation: BottomNavigationView
    private lateinit var fabCart: FloatingActionButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        bottomNavigation = findViewById(R.id.bottomNavigation)
        fabCart = findViewById(R.id.fabCart)

        if (savedInstanceState == null) show(HomeFragment())
        bottomNavigation.selectedItemId = R.id.nav_home

        bottomNavigation.setOnItemSelectedListener {
            when (it.itemId) {
                R.id.nav_home -> { show(HomeFragment()); true }
                R.id.nav_orders -> { show(OrdersFragment()); true }
                R.id.nav_coupon -> { show(CouponFragment()); true }
                R.id.nav_member -> { show(MemberFragment()); true }
                else -> false
            }
        }

        fabCart.setOnClickListener { show(CartFragment()) }
    }

    private fun show(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragmentContainer, fragment)
            .commit()
    }
}
