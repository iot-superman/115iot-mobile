package com.example.fastorder
import androidx.fragment.app.Fragment
class CouponFragment:Fragment(R.layout.fragment_coupon)
