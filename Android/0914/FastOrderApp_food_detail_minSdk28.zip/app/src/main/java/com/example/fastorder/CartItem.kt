package com.example.fastorder

data class CartItem(val food: Food, var quantity:Int = 1)
