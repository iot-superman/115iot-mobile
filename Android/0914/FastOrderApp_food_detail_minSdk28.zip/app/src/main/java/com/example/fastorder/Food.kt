package com.example.fastorder

data class Food(val id:Int,val name:String,val price:Int,val emoji:String,val category:String,val description:String)
