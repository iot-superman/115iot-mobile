package com.example.fastorder

import android.content.res.ColorStateList
import android.graphics.Typeface
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class HomeFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(R.layout.fragment_home, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val recyclerFood = view.findViewById<RecyclerView>(R.id.recyclerFood)
        val categoryContainer = view.findViewById<LinearLayout>(R.id.categoryContainer)

        val adapter = FoodAdapter(AppData.foods) { food ->
            showFoodDetailDialog(food)
        }

        recyclerFood.layoutManager = LinearLayoutManager(requireContext())
        recyclerFood.adapter = adapter

        val categories = listOf("全部", "套餐", "漢堡", "炸雞", "點心", "飲料", "甜點")
        categories.forEach { category ->
            val button = Button(requireContext()).apply {
                text = category
                textSize = 16f
                setTypeface(typeface, Typeface.BOLD)
                backgroundTintList = ColorStateList.valueOf(
                    requireContext().getColor(R.color.brand_yellow)
                )

                setOnClickListener {
                    val data = if (category == "全部") {
                        AppData.foods
                    } else {
                        AppData.foods.filter { it.category == category }
                    }
                    adapter.update(data)
                }
            }

            categoryContainer.addView(
                button,
                ViewGroup.MarginLayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply {
                    setMargins(6, 0, 6, 0)
                }
            )
        }
    }

    private fun showFoodDetailDialog(food: Food) {
        val dialogView = layoutInflater.inflate(R.layout.dialog_food_detail, null)

        val tvEmoji = dialogView.findViewById<TextView>(R.id.tvDialogEmoji)
        val tvName = dialogView.findViewById<TextView>(R.id.tvDialogName)
        val tvDescription = dialogView.findViewById<TextView>(R.id.tvDialogDescription)
        val tvPrice = dialogView.findViewById<TextView>(R.id.tvDialogPrice)
        val tvQuantity = dialogView.findViewById<TextView>(R.id.tvQuantity)
        val tvSubtotal = dialogView.findViewById<TextView>(R.id.tvSubtotal)
        val btnMinus = dialogView.findViewById<Button>(R.id.btnMinus)
        val btnPlus = dialogView.findViewById<Button>(R.id.btnPlus)
        val btnAddToCart = dialogView.findViewById<Button>(R.id.btnAddToCart)

        var quantity = 1

        tvEmoji.text = food.emoji
        tvName.text = food.name
        tvDescription.text = food.description
        tvPrice.text = "單價：NT$ ${food.price}"

        fun updateQuantity() {
            tvQuantity.text = quantity.toString()
            tvSubtotal.text = "小計：NT$ ${food.price * quantity}"
            btnMinus.isEnabled = quantity > 1
        }

        updateQuantity()

        val dialog = AlertDialog.Builder(requireContext())
            .setView(dialogView)
            .create()

        btnMinus.setOnClickListener {
            if (quantity > 1) {
                quantity--
                updateQuantity()
            }
        }

        btnPlus.setOnClickListener {
            quantity++
            updateQuantity()
        }

        btnAddToCart.setOnClickListener {
            AppData.addToCart(food, quantity)
            Toast.makeText(
                requireContext(),
                "${food.name} × $quantity 已加入購物車",
                Toast.LENGTH_SHORT
            ).show()
            dialog.dismiss()
        }

        dialog.show()
    }
}
