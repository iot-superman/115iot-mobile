package com.example.fastorder

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class FoodAdapter(private var data: List<Food>, private val onAdd: (Food) -> Unit) : RecyclerView.Adapter<FoodAdapter.VH>() {
    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val tvEmoji: TextView = view.findViewById(R.id.tvEmoji)
        val tvName: TextView = view.findViewById(R.id.tvName)
        val tvDesc: TextView = view.findViewById(R.id.tvDesc)
        val tvPrice: TextView = view.findViewById(R.id.tvPrice)
        val btnAdd: Button = view.findViewById(R.id.btnAdd)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_food, parent, false)
        return VH(view)
    }

    override fun getItemCount() = data.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val food = data[position]
        holder.tvEmoji.text = food.emoji
        holder.tvName.text = food.name
        holder.tvDesc.text = food.description
        holder.tvPrice.text = "NT$ ${food.price}"
        holder.btnAdd.setOnClickListener { onAdd(food) }
    }

    fun update(newData: List<Food>) {
        data = newData
        notifyDataSetChanged()
    }
}
