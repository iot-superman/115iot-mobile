package com.example.fastorder

data class Order(val orderNo:String,val diningType:String,val items:List<CartItem>,val total:Int,val note:String)
