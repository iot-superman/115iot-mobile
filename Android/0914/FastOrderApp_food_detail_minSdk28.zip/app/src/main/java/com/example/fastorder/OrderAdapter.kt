package com.example.fastorder

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class OrderAdapter : RecyclerView.Adapter<OrderAdapter.VH>() {
    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val tvOrderNo: TextView = view.findViewById(R.id.tvOrderNo)
        val tvOrderInfo: TextView = view.findViewById(R.id.tvOrderInfo)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_order, parent, false)
        return VH(view)
    }

    override fun getItemCount() = AppData.orders.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val order = AppData.orders.reversed()[position]
        holder.tvOrderNo.text = "取餐號碼 ${order.orderNo}"
        val lines = order.items.joinToString("\n") { "${it.food.name} × ${it.quantity}" }
        holder.tvOrderInfo.text = "${order.diningType}\n$lines\n總金額 NT$ ${order.total}" +
            if (order.note.isBlank()) "" else "\n備註：${order.note}"
    }
}
