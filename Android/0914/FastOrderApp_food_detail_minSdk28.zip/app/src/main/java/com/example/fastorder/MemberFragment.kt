package com.example.fastorder
import androidx.fragment.app.Fragment
class MemberFragment:Fragment(R.layout.fragment_member)
