package com.example.fastorder

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class CartAdapter(private val changed: () -> Unit) : RecyclerView.Adapter<CartAdapter.VH>() {
    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val tvEmoji: TextView = view.findViewById(R.id.tvEmoji)
        val tvName: TextView = view.findViewById(R.id.tvName)
        val tvSubtotal: TextView = view.findViewById(R.id.tvSubtotal)
        val btnMinus: ImageButton = view.findViewById(R.id.btnMinus)
        val tvQty: TextView = view.findViewById(R.id.tvQty)
        val btnPlus: ImageButton = view.findViewById(R.id.btnPlus)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_cart, parent, false)
        return VH(view)
    }

    override fun getItemCount() = AppData.cart.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = AppData.cart[position]
        holder.tvEmoji.text = item.food.emoji
        holder.tvName.text = item.food.name
        holder.tvQty.text = item.quantity.toString()
        holder.tvSubtotal.text = "NT$ ${item.food.price * item.quantity}"
        holder.btnPlus.setOnClickListener {
            item.quantity++
            notifyItemChanged(position)
            changed()
        }
        holder.btnMinus.setOnClickListener {
            if (item.quantity > 1) {
                item.quantity--
                notifyItemChanged(position)
            } else {
                AppData.cart.removeAt(position)
                notifyItemRemoved(position)
                notifyItemRangeChanged(position, AppData.cart.size)
            }
            changed()
        }
    }
}
