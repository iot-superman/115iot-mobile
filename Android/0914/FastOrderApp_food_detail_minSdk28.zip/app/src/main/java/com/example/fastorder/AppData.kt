package com.example.fastorder

object AppData {
    val foods = listOf(
        Food(1,"經典牛肉漢堡",129,"🍔","漢堡","牛肉、生菜、起司與特製醬料"),
        Food(2,"雙層起司漢堡",159,"🍔","漢堡","雙層牛肉與雙份起司"),
        Food(3,"香酥炸雞",69,"🍗","炸雞","外酥內嫩的香酥炸雞"),
        Food(4,"黃金薯條",49,"🍟","點心","外酥內鬆的經典薯條"),
        Food(5,"雞塊 6 塊",79,"🍗","點心","酥脆雞塊搭配沾醬"),
        Food(6,"可樂",35,"🥤","飲料","冰涼碳酸飲料"),
        Food(7,"紅茶",35,"🧋","飲料","清爽無糖或微糖紅茶"),
        Food(8,"香草冰淇淋",45,"🍦","甜點","濃郁香草風味"),
        Food(9,"牛肉漢堡套餐",199,"🍔","套餐","漢堡＋中薯＋中杯飲料")
    )
    val cart = mutableListOf<CartItem>()
    val orders = mutableListOf<Order>()
    fun addToCart(food: Food, quantity: Int = 1) {
        if (quantity <= 0) return
        val item = cart.find { it.food.id == food.id }
        if (item == null) {
            cart.add(CartItem(food, quantity))
        } else {
            item.quantity += quantity
        }
    }
    fun total()=cart.sumOf{it.food.price*it.quantity}
    fun itemCount()=cart.sumOf{it.quantity}
}
