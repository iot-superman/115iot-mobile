package com.example.fastorder

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class OrdersFragment : Fragment() {
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        return inflater.inflate(R.layout.fragment_orders, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val recyclerOrders = view.findViewById<RecyclerView>(R.id.recyclerOrders)
        val tvEmpty = view.findViewById<TextView>(R.id.tvEmpty)
        recyclerOrders.layoutManager = LinearLayoutManager(requireContext())
        recyclerOrders.adapter = OrderAdapter()
        tvEmpty.visibility = if (AppData.orders.isEmpty()) View.VISIBLE else View.GONE
    }
}
