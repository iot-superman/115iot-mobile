注意：(1) Thingspeak.txt中的{Your Key}必須以自己的ThingSpeak Channel Write API金鑰取代。

      (2) IFTTTLine.txt中的{Event Name}、{Your Key}必須分別以自己IFTTT的事件名稱與金鑰取代。

      (3) IFTTTMail.txt中的{Event Name}、{Your Key}必須分別以自己IFTTT的事件名稱與金鑰取代，{Your eMail Address}則以自己的信箱取代
